**ParkAdmin**

Parkolás automatizálását elősegítő rendszer

*Sorompó röviden*

2026

# **Tartalomjegyzék** {#tartalomjegyzék}

[**Tartalomjegyzék	2**](#tartalomjegyzék)

[**1\. Bevezetés	3**](#1.-bevezetés)

[1.1 Felvezetés	3](#1.1-felvezetés)

[1.2 Rövid leírás	3](#1.2-rövid-leírás)

[1.3 Működés	3](#1.3-működés)

[**2\. Rendszeráttekintés	3**](#2.-rendszeráttekintés)

[2.1 Architektúra	3](#2.1-architektúra)

[2.2 Fájlstruktúra	3](#2.2-fájlstruktúra)

[**3\. Frontend	5**](#3.-frontend)

[3.1 Technológiai stack	5](#3.1-technológiai-stack)

[3.2 Komponensek	5](#3.2-komponensek)

[3.2.1 App (gyökér komponens)	5](#3.2.1-app-\(gyökér-komponens\))

[3.2.2 Login	5](#3.2.2-login)

[3.2.3 DashboardTab (Műszerfal)	5](#3.2.3-dashboardtab-\(műszerfal\))

[3.2.4 WhitelistTab	5](#3.2.4-whitelisttab)

[3.2.5 LogsTab (Eseménynapló)	5](#3.2.5-logstab-\(eseménynapló\))

[3.3 Téma és stílusrendszer	6](#3.3-téma-és-stílusrendszer)

[**4\. Backend (teszt.py)	7**](#4.-backend-\(teszt.py\))

[4.1 Flask alkalmazás	7](#4.1-flask-alkalmazás)

[4.2 Adatbázis (MongoDB)	7](#4.2-adatbázis-\(mongodb\))

[4.3 Képfeldolgozás és rendszámfelismerés	7](#4.3-képfeldolgozás-és-rendszámfelismerés)

[**5\. API modul (Api.js)	8**](#5.-api-modul-\(api.js\))

[5.1 jfetch segédfüggvény	8](#5.1-jfetch-segédfüggvény)

[5.2 Mock mód	8](#5.2-mock-mód)

[5.3 Kamerakép URL	8](#5.3-kamerakép-url)

[**6\. Telepítés és futtatás	9**](#6.-telepítés-és-futtatás)

[6.1 Python függőségek telepítése	9](#6.1-python-függőségek-telepítése)

[6.2 A backend szerver indítása	9](#6.2-a-backend-szerver-indítása)

[6.3 A frontend megnyitása	9](#6.3-a-frontend-megnyitása)

[6.4 Környezeti változók	9](#6.4-környezeti-változók)

[**7\. Biztonsági megfontolások	10**](#7.-biztonsági-megfontolások)

[**8\. Bővítési lehetőségek	10**](#8.-bővítési-lehetőségek)

[**9\. Összefoglalás	10**](#9.-összefoglalás)

# **1\. Bevezetés** {#1.-bevezetés}

## **1.1 Felvezetés** {#1.1-felvezetés}

Az oktatóink tanításunk során számtalanszor szóba hozták az intézmény jelentősen kis parkolóját, amit bár személyzetnek alakítottak ki, használva volt diákok által is, ezzel eredményezve, hogy nem fért el a személyzet a saját parkolójába. Mi ennek megoldását vettük inspirációként és elkészítettük a ParkAdmin parkolórendszer-kezelő-t.

## **1.2 Rövid leírás** {#1.2-rövid-leírás}

A ParkAdmin egy webalapú parkolórendszer-kezelő alkalmazás, amely rendszámfelismerésen alapuló sorompóvezérlést, whitelist-kezelést és eseménynaplózást tesz lehetővé. A rendszer React-alapú felhasználói felületből, Python/Flask REST API-ból, OpenCV és Pytesseract képfeldolgozó modulokból, valamint MongoDB adatbázisból épül fel.

## **1.3 Működés** {#1.3-működés}

Az alkalmazás célja, hogy az engedélyezett járművek automatikusan, kamerafelvétel alapján léphessenek be a parkolóterületre, miközben az üzemeltetők valós időben nyomon követhetik az eseményeket, és karban tarthatják az engedélyezett rendszámok listáját.

# 

# **2\. Rendszeráttekintés** {#2.-rendszeráttekintés}

## **2.1 Architektúra** {#2.1-architektúra}

A rendszer háromrétegű architektúrán alapul. A prezentációs réteget egy egyoldalas React-alkalmazás alkotja, amely böngészőben fut. Az üzleti logika rétegét egy Python Flask-alapú REST API szerver képviseli, amely a kamera kezelését, a rendszámfelismerést és a sorompóvezérlést végzi. Az adatrétegben MongoDB felhőadatbázis (Atlas) tárolja a whitelist-bejegyzéseket és az eseménynaplókat.

A frontend és a backend kommunikációja HTTP JSON API-n keresztül történik, alapértelmezés szerint a localhost:5050/api végponton. A frontend önállóan is futtatható mock adatokkal, valódi backend nélkül is.

## **2.2 Fájlstruktúra** {#2.2-fájlstruktúra}

A projekt az alábbi főbb fájlokból áll:

* html.html — A belépési pont (entry point), betölti a React könyvtárakat, a stíluslapot és a JavaScript modulokat.

* App.jsx — A teljes React-alkalmazás komponenseit tartalmazó fájl (bejelentkezés, műszerfal, whitelist, napló).

* Api.js — Az API hívásokat absztraháló modul; valódi backend hiányában mock adatokat szolgáltat.

* Styles.css — Az alkalmazás teljes stílusleírása, dark/light témával.

* teszt.py — A Flask REST API szerver és az OCR-alapú rendszámfelismerő fő Python fájlja.

* requirements.txt — A Python függőségek listája.

# **3\. Frontend** {#3.-frontend}

## **3.1 Technológiai stack** {#3.1-technológiai-stack}

* React 18.2 — komponensalapú UI keretrendszer

* ReactDOM — DOM renderelés

* Babel Standalone — JSX transzpilálás (mi ez a szó ember) böngészőben, build lépés nélkül

* Vanilla CSS — saját stílus, CSS változókkal és dark/light témával

## **3.2 Komponensek** {#3.2-komponensek}

### **3.2.1 App (gyökér komponens)** {#3.2.1-app-(gyökér-komponens)}

Az App komponens tartalmazza az alkalmazás teljes állapotát és vezérlési logikáját. Kezeli a bejelentkezési állapotot (authed), a témát (dark/light), az aktív lapfület, valamint a munkamenet-időzítőt. A munkamenet 60 másodperces inaktivitás után automatikusan lejár, és visszajelzést ad a felhasználónak (visszaszámlálós időzítő bal alul).

A React useState és useEffect hookok segítségével reaktívan frissül az állapot. Az eseményfigyelők (mousemove, mousedown, keydown, touchstart) a munkamenet-időzítőt minden interakciónál visszaállítják(hogy ne jelentkezzen ki 60 másodpercenként).

### **3.2.2 Login** {#3.2.2-login}

A bejelentkezési képernyő felhasználónév és jelszó beviteli mezőket tartalmaz. Sikertelen belépéskor hibaüzenetet jelenít meg. Lejárt munkamenet esetén tájékoztató szöveget mutat. A demo hozzáférési adatok: admin / admin123.

### **3.2.3 DashboardTab (Műszerfal)** {#3.2.3-dashboardtab-(műszerfal)}

A műszerfal három fő elemet tartalmaz. A sorompó állapotát mutató kártya (NYITVA/ZÁRVA) zöld, illetve piros jelzőfénnyel, és egy manuális nyitás gombbal. Az utoljára felismert rendszám kártyán megjelenik a rendszám és az eredmény (whitelist-en szerepel-e). A kamera feed kártya 2-ször frissül másodpercenként és JPEG képet tölt be az API-tól és megjeleníti élő nézetként.

A rendszámfelismerés eredményét a komponens másodpercenként lekérdezi a /api/last-recognition végponttól. Ha a státusz 'allowed', a sorompó automatikusan 4 másodpercre nyitva marad.

### **3.2.4 WhitelistTab** {#3.2.4-whitelisttab}

A whitelist kezelő lapon az üzemeltető megtekintheti, keresheti, bővítheti és törölheti az engedélyezett személyek bejegyzéseit. Minden bejegyzés tartalmaz egy nevet és egy rendszámot. Az elemek valós időben szűrhetők a keresőmezőben, mind névre, mind rendszámra. Hozzáadáskor a rendszám automatikusan nagybetűssé alakul.

### **3.2.5 LogsTab (Eseménynapló)** {#3.2.5-logstab-(eseménynapló)}

A napló lapon az összes rögzített belépési esemény megtekinthető időrendben, visszafelé csökkenő sorrendben. A bejegyzések szűrhetők: összes, engedélyezett, vagy megtagadott. Minden sor tartalmazza az időpontot, a rendszámot, a nevet és az eredményt (zöld/piros).

## **3.3 Téma és stílusrendszer** {#3.3-téma-és-stílusrendszer}

A Styles.css fájl CSS változókon (custom properties) alapuló témázást alkalmaz. Az alapértelmezett (dark) téma sötét lilás-fekete hátterű. A light téma kék árnyalatú, világos felületre vált. A téma váltása a localStorage-ban rögzítődik, így oldalbetöltések között is megmarad.

Az alkalmazás reszponzív: a grid-alapú elrendezés (dash-grid) különböző képernyőszélességekre adaptálódik.

# **4\. Backend (teszt.py)** {#4.-backend-(teszt.py)}

## **4.1 Flask alkalmazás** {#4.1-flask-alkalmazás}

A backend Python 3 alapú Flask webszerver, amely REST API-t nyújt a frontend számára. A CORS modul engedélyezi a cross-origin kéréseket, így a frontend és backend eltérő portról is kommunikálhat. Az alkalmazás alapértelmezés szerint a 0.0.0.0:5050 címen indul el.

## **4.2 Adatbázis (MongoDB)** {#4.2-adatbázis-(mongodb)}

A rendszer MongoDB Atlas felhőadatbázist használ. Az alkalmazás két gyűjteményt kezel: a whitelist gyűjtemény tartalmazza az engedélyezett rendszámokat és a hozzájuk tartozó neveket, a logs gyűjtemény pedig a belépési eseményeket rögzíti.

A kapcsolat az alábbi környezeti változókkal konfigurálható: MONGO\_URI (az Atlas connection string), MONGO\_DB (az adatbázis neve, alapértelmezés: sorompoadatbazis). Ha a MongoDB nem elérhető, az API 503-as hibát ad vissza, megelőzve az alkalmazás összeomlását.

A backend rugalmasan kezeli az eltérő sémájú adatokat: a rendszám a plate, rendszam, rendszám vagy plate\_number mezőkből is kiolvasható. A státusz az allowed/engedélyezett/ok/igen kulcsszavakra illeszkedik.

## **4.3 Képfeldolgozás és rendszámfelismerés** {#4.3-képfeldolgozás-és-rendszámfelismerés}

Az autonóm üzemmód (scan mód) indításakor az alkalmazás az OpenCV könyvtárat használja a kamerakép rögzítésére. A képelőfeldolgozás szürkeárnyalatosítással és Otsu küszöböléssel élesíti a rendszám karaktereit. Ezt követően a Pytesseract OCR azonosítja a rendszámot.

A felismerés közelség érzékelő szenzor hiánya miatt 3 másodpercenként fut. Ha a felismert rendszám szerepel a whitelist-en, a sorompó nyit, a találat az ALLOWED státusszal kerül a naplóba; ellenkező esetben DENIED státusszal. Az utolsó felismerés eredménye globálisan elérhető, és a React frontend másodpercenként lekérdezi.

# **5\. API modul (Api.js)** {#5.-api-modul-(api.js)}

Az Api.js modul áthidaló réteget képez a frontend és a backend között. A modul a window.API globális objektumot tölti fel az összes API-hívó függvénnyel, így a React komponensek egységesen, a belső implementáció ismerete nélkül használhatják azt.

## **5.1 jfetch segédfüggvény** {#5.1-jfetch-segédfüggvény}

A jfetch függvény minden HTTP kérést kezel: JSON fejlécet állít be, kiolvas JSON vagy szöveges választ, és hiba esetén egységes {ok: false, error: ...} objektumot ad vissza. Ez biztosítja, hogy a komponenseknek ne kelljen külön hibakezelést implementálniuk.

## **5.2 Mock mód** {#5.2-mock-mód}

Ha a valódi backend nem csatlakozik, az Api.js automatikusan mock implementációra vált. Ez lehetővé teszi a frontend önálló fejlesztését és tesztelését a Python szerver futtatása nélkül is. A mock adatok három előre definiált whitelist-bejegyzést és öt eseménynapló bejegyzést tartalmaznak.

## **5.3 Kamerakép URL** {#5.3-kamerakép-url}

A camJpegUrl() függvény minden hívásakor egy friss URL-t generál az aktuális időbélyeggel (?ts=...), ezzel megakadályozza a böngésző cache-elését, és biztosítja, hogy a műszerfal mindig a legfrissebb képkockát töltse be.

# **6\. Telepítés és futtatás** {#6.-telepítés-és-futtatás}

## **6.1 Python függőségek telepítése** {#6.1-python-függőségek-telepítése}

A Python oldal az alábbi könyvtárakat igényli (requirements.txt):

* flask — webszerver és REST API keretrendszer

* flask-cors — cross-origin resource sharing támogatás

* pymongo — MongoDB kliens

* opencv-python — kamera elérés és képfeldolgozás

* pytesseract — Tesseract OCR Python binding

A telepítés parancsa:

pip install \-r requirements.txt

## **6.2 A backend szerver indítása** {#6.2-a-backend-szerver-indítása}

API szerver indítása (React frontend kiszolgálásához):

python3 teszt.py

Autonóm OCR szkennelő mód indítása:

python3 teszt.py scan

## **6.3 A frontend megnyitása** {#6.3-a-frontend-megnyitása}

A html.html fájl közvetlenül megnyitható böngészőben, azonban a backend API eléréséhez szükséges, hogy a Flask szerver fusson a localhost:5050-es porton. Backend nélkül az alkalmazás mock adatokkal működik.

## **6.4 Környezeti változók** {#6.4-környezeti-változók}

* MONGO\_URI — MongoDB Atlas connection string (alapértelmezett értéke a kódban hardcoded)

* MONGO\_DB — Az adatbázis neve (alapértelmezett: sorompoadatbazis)

* PORT — A Flask szerver portja (alapértelmezett: 5050\)

# **7\. Biztonsági megfontolások** {#7.-biztonsági-megfontolások}

A jelenlegi implementáció fejlesztői / bemutató célú rendszert valósít meg. Éles üzemeltetés előtt az alábbi területek fejlesztése szükséges:

* Hitelesítés: A bejelentkezési logika jelenleg hardcoded admin/admin123 adatokkal működik. Éles rendszerben jelszókivonatolást (pl. bcrypt) és biztonságos felhasználó-kezelést kell alkalmazni.

* Jogosultságkezelés: Az API-végpontok jelenleg session- vagy token-alapú hitelesítés nélkül érhetők el.

* CORS konfiguráció: A flask-cors jelenleg minden origint engedélyez.

* MongoDB hitelesítési adatok: A connection string jelenleg a forráskódba van égetve. 

* Kamerahozzáférés: A /api/cam.jpg végpont minden hívásra megnyit és zár egy kameraeszközt.

# **8\. Bővítési lehetőségek** {#8.-bővítési-lehetőségek}

A rendszer jelenlegi architektúrája lehetővé teszi az alábbi irányokban való fejlesztést:

* Valódi sorompóvezérlés.

* Többkamerás támogatás.

* Értesítések: Ismeretlen rendszám észlelésekor e-mail vagy push-értesítés küldhető.

* Statisztikák: A naplóadatokból időalapú grafikonok.

* Felhasználói szerepkörök.

* Exportálás: Az eseménynapló PDF formátumban letölthető.

# **9\. Összefoglalás** {#9.-összefoglalás}

A ParkAdmin egy kompakt, modern technológiákra épülő parkolórendszer-kezelő megoldás, amely ötvözi a gépi látás alapú rendszámfelismerést, a felhőalapú adatkezelést és a reszponzív webes felhasználói felületet. A rendszer moduláris kialakításának köszönhetően könnyen bővíthető és testreszabható valós üzemi igényekhez.

A frontend önállóan is működőképes demo módban, ami megkönnyíti a fejlesztést és bemutatást. A backend Flask és OpenCV kombinációja hatékony megoldást nyújt alacsony erőforrásigényű hardveren (pl. Raspberry Pi) is futtatható rendszámfelismeréshez.