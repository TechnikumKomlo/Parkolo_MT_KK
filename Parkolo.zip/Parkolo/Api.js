const API_BASE = (typeof window !== "undefined" && window.API_BASE) || "http://localhost:5050/api";

async function jfetch(path, opts = {}) {
  const r = await fetch(`${API_BASE}${path}`, {
    ...opts,
    headers: { "Content-Type": "application/json", ...(opts.headers || {}) },
  });
  const ct = r.headers.get("content-type") || "";
  const data = ct.includes("application/json") ? await r.json() : await r.text();
  if (!r.ok) {
    return { ok: false, error: (data && data.error) || String(data || r.statusText) };
  }
  return data;
}

var API = window.API || {
  baseUrl: API_BASE,

  login: async (u, p) =>
    jfetch("/login", { method: "POST", body: JSON.stringify({ user: u, pass: p }) }),

  getLogs: async () => jfetch("/logs"),

  getLastRecognition: async () => jfetch("/last-recognition"),

  openBarrier: async (plate) =>
    jfetch("/open-barrier", { method: "POST", body: JSON.stringify({ plate }) }),

  getWL: async () => jfetch("/wl"),

  addWL: async (e) => jfetch("/wl", { method: "POST", body: JSON.stringify(e) }),

  delWL: async (id) => jfetch(`/wl/${encodeURIComponent(id)}`, { method: "DELETE" }),

  camJpegUrl: (ts = Date.now()) => `${API_BASE}/cam.jpg?ts=${ts}`,
};

window.API = API;

const delay = ms => new Promise(r => setTimeout(r, ms));

let wl = [
    { id: 1, name: "Kovács János", plate: "ABC-123" },
    { id: 2, name: "Nagy Péter",   plate: "XYZ-789" },
    { id: 3, name: "Szabó Éva",    plate: "DEF-456" },
];

const mockLogs = [
    { id:1, plate:"ABC-123", name:"Kovács János", time:"2026-03-04 08:12", status:"allowed" },
    { id:2, plate:"QQQ-000", name:"Ismeretlen",   time:"2026-03-04 08:45", status:"denied"  },
    { id:3, plate:"XYZ-789", name:"Nagy Péter",   time:"2026-03-04 09:01", status:"allowed" },
    { id:4, plate:"DEF-456", name:"Szabó Éva",    time:"2026-03-04 09:33", status:"allowed" },
    { id:5, plate:"LMN-321", name:"Ismeretlen",   time:"2026-03-04 10:05", status:"denied"  },
];

if (!window.API) {
  API = {
      login:       async (u, p) => { await delay(600); return { ok: u === "admin" && p === "admin123" }; },
      getLogs:     async ()     => { await delay(300); return [...mockLogs]; },
      openBarrier: async ()     => { await delay(400); return { ok: true }; },
      getWL:       async ()     => { await delay(300); return [...wl]; },
      addWL:       async e      => { await delay(300); wl.push({ ...e, id: Date.now() }); },
      delWL:       async id     => { await delay(200); wl = wl.filter(e => e.id !== id); },
  };
  window.API = API;
};