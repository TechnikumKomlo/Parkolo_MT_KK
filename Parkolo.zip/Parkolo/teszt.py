import os
import time
from datetime import datetime, timezone

try:
    import cv2  # type: ignore
except Exception:  # pragma: no cover
    cv2 = None

try:
    import pytesseract  # type: ignore
except Exception:  # pragma: no cover
    pytesseract = None
from bson import ObjectId
from flask import Flask, Response, jsonify, request
from flask_cors import CORS
from pymongo import MongoClient

MONGO_URI = os.environ.get(
    "MONGO_URI",
    "mongodb+srv://birodalom468_db_user:K1i3VU8B8Ql5Hzam@cluster0.hw1tivn.mongodb.net/",
)

_mongo = None


def _get_db():
    #503 ha mongodb nem elérhető
    global _mongo
    if _mongo is None:
        _mongo = MongoClient(MONGO_URI, serverSelectionTimeoutMS=3000)
    return _mongo.get_database(os.environ.get("MONGO_DB", "sorompoadatbazis"))


def _wl_col():
    return _get_db()["whitelist"]


def _logs_col():
    return _get_db()["logs"]

app = Flask(__name__)
CORS(app)

LAST_RECOGNITION = {"plate": None, "name": None, "time": None, "status": None}


def preprocess_image(frame):
    if cv2 is None:
        raise RuntimeError("OpenCV (cv2) is not installed")
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    _, thresh = cv2.threshold(gray, 170, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    return thresh


def _iso_now():
    return datetime.now(timezone.utc).astimezone().strftime("%Y-%m-%d %H:%M:%S")


def _as_str(v, default=""):
    if v is None:
        return default
    return str(v).strip()


def _plate_match(plate):
    """Mongo lekérdezés: a régi / vegyes sémákban többféle mezőnéven is szerepelhet a rendszám."""
    p = _as_str(plate).upper().replace(" ", "")
    if not p:
        return {"_id": None}
    return {
        "$or": [
            {"plate": p},
            {"rendszam": p},
            {"rendszám": p},
            {"plate_number": p},
        ]
    }


def _norm_status(v):
    if v is None:
        return "denied"
    sl = str(v).strip().lower()
    if sl in ("allowed", "engedelyezett", "engedélyezett", "ok", "igen", "true", "1", "yes"):
        return "allowed"
    return "denied"


def _norm_wl(doc):
    """Egységes {id, name, plate} a React számára — támogatja a nem `name`/`plate` mezőket is."""
    if not doc:
        return None
    d = dict(doc)
    oid = str(d["_id"]) if "_id" in d else _as_str(d.get("id"))
    name = d.get("name") or d.get("nev") or d.get("owner") or d.get("vezeteknev") or ""
    plate = d.get("plate") or d.get("rendszam") or d.get("rendszám") or d.get("plate_number") or ""
    return {"id": oid, "name": _as_str(name), "plate": _as_str(plate).upper().replace(" ", "")}


def _norm_log(doc):
    if not doc:
        return None
    d = dict(doc)
    oid = str(d["_id"]) if "_id" in d else _as_str(d.get("id"))
    plate = d.get("plate") or d.get("rendszam") or d.get("rendszám") or d.get("plate_number") or ""
    name = d.get("name") or d.get("nev") or ""
    t = d.get("time") or d.get("timestamp") or d.get("datum") or d.get("created_at") or ""
    status = _norm_status(d.get("status") or d.get("eredmeny"))
    return {
        "id": oid,
        "plate": _as_str(plate).upper().replace(" ", ""),
        "name": _as_str(name) or "Ismeretlen",
        "time": _as_str(t),
        "status": status,
    }


@app.get("/api/health")
def health():
    return jsonify({"ok": True})


@app.post("/api/login")
def login():
    body = request.get_json(silent=True) or {}
    u = str(body.get("user", ""))
    p = str(body.get("pass", ""))
    return jsonify({"ok": u == "admin" and p == "admin123"})


@app.get("/api/wl")
def get_wl():
    try:
        rows = [_norm_wl(d) for d in _wl_col().find({})]
        rows = [r for r in rows if r and r.get("id")]
        rows.sort(key=lambda r: (r["name"].lower(), r["plate"]))
        return jsonify(rows)
    except Exception as e:
        return jsonify({"ok": False, "error": f"Mongo unavailable: {e}"}), 503


@app.post("/api/wl")
def add_wl():
    body = request.get_json(silent=True) or {}
    name = str(body.get("name", "")).strip()
    plate = str(body.get("plate", "")).strip().upper()
    if not name or not plate:
        return jsonify({"ok": False, "error": "Missing name/plate"}), 400
    try:
        res = _wl_col().insert_one({"name": name, "plate": plate})
        return jsonify({"ok": True, "id": str(res.inserted_id)})
    except Exception as e:
        return jsonify({"ok": False, "error": f"Mongo unavailable: {e}"}), 503


@app.delete("/api/wl/<id>")
def del_wl(id):
    try:
        oid = ObjectId(id)
    except Exception:
        return jsonify({"ok": False, "error": "Bad id"}), 400
    try:
        _wl_col().delete_one({"_id": oid})
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"ok": False, "error": f"Mongo unavailable: {e}"}), 503


@app.get("/api/logs")
def get_logs():
    try:
        rows = [_norm_log(d) for d in _logs_col().find({}).limit(500)]
        rows = [r for r in rows if r and r.get("id")]
        rows.sort(key=lambda r: r.get("time") or "", reverse=True)
        return jsonify(rows[:200])
    except Exception as e:
        return jsonify({"ok": False, "error": f"Mongo unavailable: {e}"}), 503


@app.get("/api/last-recognition")
def last_recognition():
    return jsonify(LAST_RECOGNITION)


@app.post("/api/open-barrier")
def open_barrier():
    body = request.get_json(silent=True) or {}
    if body.get("manual") is True:
        # ha lenne igazi akkor itt lenne a sorompó irányítás
        return jsonify({"ok": True})

    plate = str(body.get("plate", "")).strip().upper()
    if not plate:
        return jsonify({"ok": False, "error": "Missing plate"}), 400
    try:
        allowed = _wl_col().find_one(_plate_match(plate), {"_id": 1}) is not None
    except Exception as e:
        return jsonify({"ok": False, "error": f"Mongo unavailable: {e}"}), 503

    if not allowed:
        return jsonify({"ok": False, "error": "Plate not in whitelist"}), 403

    # ha lenne igazi akkor itt lenne a sorompó irányítás
    return jsonify({"ok": True})


@app.get("/api/cam.jpg")
def cam_jpg():
    #képet küld a weblapra processing nélkül
    if cv2 is None:
        return jsonify({"ok": False, "error": "OpenCV (cv2) is not installed"}), 500
    cap = cv2.VideoCapture(0)
    try:
        ok, frame = cap.read()
        if not ok or frame is None:
            return jsonify({"ok": False, "error": "Camera read failed"}), 500
        ok, buf = cv2.imencode(".jpg", frame, [int(cv2.IMWRITE_JPEG_QUALITY), 85])
        if not ok:
            return jsonify({"ok": False, "error": "JPEG encode failed"}), 500
        return Response(buf.tobytes(), mimetype="image/jpeg")
    finally:
        cap.release()


def main():
    if cv2 is None or pytesseract is None:
        raise RuntimeError("Scan mode requires opencv-python and pytesseract to be installed")
    cap = cv2.VideoCapture(0)
    last_scan_time = 0
    scan_interval = 3

    print("Autonóm rendszer elindítva (Szkennelés 3 másodpercenként)")
    print("Kilépéshez nyomj q-t a kamera ablakban.")

    while True:
        ret, frame = cap.read()
        if not ret: break

        current_time = time.time()

        cv2.imshow('Sorompo Kamera', frame)

        if current_time - last_scan_time > scan_interval:
            processed = preprocess_image(frame)

            raw_text = pytesseract.image_to_string(processed, config='--psm 7')
            found_plate = raw_text.strip().replace(" ", "").upper()

            if found_plate:
                match = _wl_col().find_one(_plate_match(found_plate), {})
                if match:
                    nm = (_norm_wl(match) or {}).get("name") or "Ismeretlen"
                    print(f"[{time.strftime('%H:%M:%S')}] Rendszám: {found_plate} | engedélyezve")
                    LAST_RECOGNITION.update(
                        {
                            "plate": found_plate,
                            "name": nm,
                            "time": _iso_now(),
                            "status": "allowed",
                        }
                    )
                    _logs_col().insert_one(
                        {
                            "plate": found_plate,
                            "name": nm,
                            "time": _iso_now(),
                            "status": "allowed",
                        }
                    )
                else:
                    print(f"[{time.strftime('%H:%M:%S')}] Rendszám: {found_plate} | elutasítva")
                    LAST_RECOGNITION.update(
                        {
                            "plate": found_plate,
                            "name": "Ismeretlen",
                            "time": _iso_now(),
                            "status": "denied",
                        }
                    )
                    _logs_col().insert_one(
                        {
                            "plate": found_plate,
                            "name": "Ismeretlen",
                            "time": _iso_now(),
                            "status": "denied",
                        }
                    )

            last_scan_time = current_time

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    # OCR scanner loop:
    #   python3 teszt.py scan
    # API for React:
    #   python3 teszt.py
    import sys

    if len(sys.argv) > 1 and sys.argv[1] == "scan":
        main()
    else:
        app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "5050")), debug=True)