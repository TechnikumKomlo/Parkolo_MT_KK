// app.jsx — React komponensek
// API és styles.css már be van töltve az index.html-ből

const { useState, useEffect, useRef, useCallback } = React;

//APP
function App() {
    const [authed,  setAuthed]  = useState(false);
    const [expired, setExpired] = useState(false);
    const [tab,     setTab]     = useState("dashboard");
    const [theme,   setTheme]   = useState(() => localStorage.getItem("pa-theme") || "dark");
    const [secs,    setSecs]    = useState(60);
    const timers = useRef({});

    useEffect(() => {
        document.documentElement.setAttribute("data-theme", theme);
        localStorage.setItem("pa-theme", theme);
    }, [theme]);

    const logout = useCallback((exp = false) => {
        clearTimeout(timers.current.out);
        clearInterval(timers.current.cd);
        setAuthed(false); setExpired(exp); setTab("dashboard");
    }, []);

    const resetTimer = useCallback(() => {
        clearTimeout(timers.current.out);
        clearInterval(timers.current.cd);
        setSecs(60);
        timers.current.out = setTimeout(() => logout(true), 60000);
        timers.current.cd  = setInterval(() => setSecs(s => s <= 1 ? 0 : s - 1), 1000);
    }, [logout]);

    useEffect(() => {
        if (!authed) { clearTimeout(timers.current.out); clearInterval(timers.current.cd); return; }
        resetTimer();
        const evs = ["mousemove", "mousedown", "keydown", "touchstart"];
        evs.forEach(e => window.addEventListener(e, resetTimer));
        return () => {
            clearTimeout(timers.current.out); clearInterval(timers.current.cd);
            evs.forEach(e => window.removeEventListener(e, resetTimer));
        };
    }, [authed, resetTimer]);

    if (!authed) return <Login expired={expired} onLogin={() => { setExpired(false); setAuthed(true); }} />;

    const timerColor = secs <= 15 ? "var(--red)" : secs <= 30 ? "var(--amber)" : "var(--text-dim)";
    const TABS = [["dashboard", "Műszerfal"], ["whitelist", "Whitelist"], ["logs", "Napló"]];

    return (
        <div className="shell">
            <aside className="sidebar">
                <div className="sb-logo">ParkAdmin</div>
                <nav className="sb-nav">
                    {TABS.map(([id, label]) => (
                        <button key={id} className={`nav-btn${tab === id ? " active" : ""}`} onClick={() => setTab(id)}>
                            {label}
                        </button>
                    ))}
                </nav>
                <div className="sb-foot">
                    <button className="theme-btn" onClick={() => setTheme(t => t === "dark" ? "light" : "dark")}>
                        {theme === "dark" ? "☀️ Light mód" : "🌙 Dark mód"}
                    </button>
                    <div className="timer-txt" style={{ color: timerColor }}>Munkamenet: {secs}s</div>
                    <button className="logout-btn" onClick={() => logout(false)}>Kijelentkezés</button>
                </div>
            </aside>
            <main className="main">
                {tab === "dashboard" && <DashboardTab />}
                {tab === "whitelist" && <WhitelistTab />}
                {tab === "logs"      && <LogsTab />}
            </main>
        </div>
    );
}

//LOGIN
function Login({ onLogin, expired }) {
    const [user, setUser] = useState(""), [pass, setPass] = useState("");
    const [err,  setErr]  = useState(""), [busy, setBusy] = useState(false);

    const submit = async () => {
        setErr(""); setBusy(true);
        const r = await API.login(user, pass);
        setBusy(false);
        r.ok ? onLogin() : setErr("Hibás felhasználónév vagy jelszó.");
    };

    return (
        <div className="login-bg">
            <div className="login-card fade-in">
                <div className="login-icon">P</div>
                <h1 className="login-h1">ParkAdmin</h1>
                <p className="login-sub">Beléptető rendszer</p>
                {expired && <div className="sess-exp">A munkamenet lejárt. Kérjük, lépjen be újra.</div>}
                <input className="input" style={{ marginBottom: 12 }} placeholder="Felhasználónév"
                       value={user} onChange={e => setUser(e.target.value)} onKeyDown={e => e.key === "Enter" && submit()} autoFocus />
                <input className="input" style={{ marginBottom: 12 }} type="password" placeholder="Jelszó"
                       value={pass} onChange={e => setPass(e.target.value)} onKeyDown={e => e.key === "Enter" && submit()} />
                {err && <p className="err-msg">{err}</p>}
                <button className="btn" style={{ width: "100%" }} onClick={submit} disabled={busy}>
                    {busy ? "Belépés..." : "Belépés"}
                </button>
                <p className="login-hint">Demo: admin / admin123</p>
            </div>
        </div>
    );
}

//DASHBOARD

function DashboardTab() {
    const [open,  setOpen]  = useState(false);
    const [busy,  setBusy]  = useState(false);
    const [last,  setLast]  = useState({ plate: "---", ok: false, name: "", time: "" });
    const [pulse, setPulse] = useState(false);
    const [camUrl, setCamUrl] = useState(() => (window.API?.camJpegUrl ? window.API.camJpegUrl() : ""));

    useEffect(() => {
        // backend kérés hogy melyik volt az utolsó plate
        const iv = setInterval(async () => {
            if (!window.API?.getLastRecognition) return;
            const r = await window.API.getLastRecognition();
            if (!r || r.ok === false) return;
            if (!r.plate) return;
            setLast(prev => {
                if (prev.plate === r.plate && prev.time === r.time && prev.ok === (r.status === "allowed")) return prev;
                return { plate: r.plate, ok: r.status === "allowed", name: r.name || "", time: r.time || "" };
            });
            setPulse(true); setTimeout(() => setPulse(false), 600);
            // csak akkor open ha a mongo azt mondja
            if (r.status === "allowed") { setOpen(true); setTimeout(() => setOpen(false), 4000); }
        }, 1000);
        return () => clearInterval(iv);
    }, []);

    useEffect(() => {
        // kép processing nélkül
        const iv = setInterval(() => {
            if (window.API?.camJpegUrl) setCamUrl(window.API.camJpegUrl());
        }, 500);
        return () => clearInterval(iv);
    }, []);

    const manualOpen = async () => {
        if (!last.ok) return;
        setBusy(true);
        const r = await API.openBarrier(last.plate);
        setBusy(false);
        if (r && r.ok) {
            setOpen(true);
            setTimeout(() => setOpen(false), 4000);
        }
    };

    return (
        <div className="wrap fade-in">
            <h2 className="tab-title">Műszerfal</h2>
            <div className="dash-grid">

                <div className="card">
                    <div className="card-label">Sorompó állapota</div>
                    <div className="dot-row">
                        <div className={`dot ${open ? "open" : "shut"}`} />
                        <div>
                            <div style={{ fontSize: 26, fontWeight: 700, color: open ? "var(--green)" : "var(--red)" }}>
                                {open ? "NYITVA" : "ZÁRVA"}
                            </div>
                            <div style={{ color: "var(--text-mid)", fontSize: 13, marginTop: 2 }}>
                                {open ? "Sorompó nyitva" : "Sorompó zárva"}
                            </div>
                        </div>
                    </div>
                    <button className={`btn full${busy || open || !last.ok ? " muted" : ""}`} onClick={manualOpen} disabled={busy || open || !last.ok}>
                        {busy ? "Nyitás..." : !last.ok ? "Nincs engedélyezett rendszám" : open ? "Már nyitva" : "Manuális nyitás"}
                    </button>
                </div>

                <div className="card">
                    <div className="card-label">Utoljára felismert rendszám</div>
                    <div className={`plate-box${pulse ? " pulse" : ""}`}>
                        <div style={{ color: "var(--text-mid)", fontSize: 11, letterSpacing: 2, textTransform: "uppercase" }}>Rendszám</div>
                        <div className="plate-num">{last.plate}</div>
                    </div>
                    <div className={`plate-res ${last.ok ? "ok" : "bad"}`}>
                        {last.ok ? "Whitelist-en szerepel — sorompó nyit" : "Nincs a whitelist-en — sorompó zárva"}
                    </div>
                </div>

                <div className="card full-col" id="cam-box">
                    <div className="card-label">Kamera feed</div>
                    <div className="cam-box">
                        <div className="cam-scan" />
                        {camUrl ? (
                            <img
                                src={camUrl}
                                alt="Kamera"
                                style={{
                                    width: "100%",
                                    maxHeight: 260,
                                    objectFit: "cover",
                                    borderRadius: 12,
                                    border: "1px solid var(--border)",
                                }}
                            />
                        ) : (
                            <div style={{ color: "var(--text-dim)", fontSize: 14 }}>Kamera stream betöltése...</div>
                        )}
                    </div>
                </div>

            </div>
        </div>
    );
}

//WHITELIST
function WhitelistTab() {
    const [list,    setList]    = useState([]);
    const [name,    setName]    = useState(""), [plate, setPlate] = useState("");
    const [search,  setSearch]  = useState("");
    const [loading, setLoading] = useState(true), [adding, setAdding] = useState(false);

    useEffect(() => { API.getWL().then(d => { setList(d); setLoading(false); }); }, []);

    const add = async () => {
        if (!name.trim() || !plate.trim()) return;
        setAdding(true);
        await API.addWL({ name: name.trim(), plate: plate.trim().toUpperCase() });
        setList(await API.getWL());
        setName(""); setPlate(""); setAdding(false);
    };

    const remove = async id => {
        await API.delWL(id);
        setList(l => l.filter(e => e.id !== id));
    };

    const filtered = list.filter(e =>
        e.name.toLowerCase().includes(search.toLowerCase()) ||
        e.plate.toLowerCase().includes(search.toLowerCase())
    );

    return (
        <div className="wrap fade-in">
            <h2 className="tab-title">Whitelist kezelése</h2>

            <div className="card">
                <div className="card-label">Új személy hozzáadása</div>
                <div className="add-row">
                    <input className="input" style={{ flex: 1, minWidth: 160 }} placeholder="Név"
                           value={name} onChange={e => setName(e.target.value)} />
                    <input className="input" style={{ flex: 1, minWidth: 140, fontFamily: "var(--mono)", letterSpacing: 2 }}
                           placeholder="Rendszám (pl. ABC-123)" value={plate}
                           onChange={e => setPlate(e.target.value)} onKeyDown={e => e.key === "Enter" && add()} />
                    <button className="btn" onClick={add} disabled={adding}>{adding ? "..." : "+ Hozzáadás"}</button>
                </div>
            </div>

            <div className="card">
                <div className="list-hdr">
                    <div className="card-label">Engedélyezett személyek ({filtered.length})</div>
                    <input className="input" style={{ width: 200 }} placeholder="Keresés..."
                           value={search} onChange={e => setSearch(e.target.value)} />
                </div>
                {loading ? <div className="muted-txt">Betöltés...</div> : (
                    <table className="tbl">
                        <thead><tr><th className="th">Név</th><th className="th">Rendszám</th><th className="th">Művelet</th></tr></thead>
                        <tbody>
                        {filtered.map(e => (
                            <tr key={e.id} className="tr">
                                <td className="td">{e.name}</td>
                                <td className="td mono">{e.plate}</td>
                                <td className="td"><button className="btn del" onClick={() => remove(e.id)}>Törlés</button></td>
                            </tr>
                        ))}
                        {!filtered.length && (
                            <tr><td colSpan={3} className="td" style={{ textAlign: "center", color: "var(--text-dim)" }}>Nincs találat</td></tr>
                        )}
                        </tbody>
                    </table>
                )}
            </div>
        </div>
    );
}

//LOGS
function LogsTab() {
    const [data,    setData]    = useState([]);
    const [loading, setLoading] = useState(true);
    const [filter,  setFilter]  = useState("all");

    useEffect(() => { API.getLogs().then(d => { setData(d); setLoading(false); }); }, []);

    const rows = filter === "all" ? data : data.filter(l => l.status === filter);
    const FILTERS = [["all", "Összes"], ["allowed", "Engedélyezett"], ["denied", "Megtagadott"]];

    return (
        <div className="wrap fade-in">
            <h2 className="tab-title">Eseménynapló</h2>
            <div className="card">
                <div className="filters">
                    {FILTERS.map(([v, l]) => (
                        <button key={v} className={`filter-btn${filter === v ? " on" : ""}`} onClick={() => setFilter(v)}>{l}</button>
                    ))}
                    <span style={{ marginLeft: "auto", color: "var(--text-dim)", fontSize: 13 }}>{rows.length} esemény</span>
                </div>
                {loading ? <div className="muted-txt">Betöltés...</div> : (
                    <table className="tbl">
                        <thead>
                        <tr><th className="th">Idő</th><th className="th">Rendszám</th><th className="th">Név</th><th className="th">Eredmény</th></tr>
                        </thead>
                        <tbody>
                        {rows.map(l => (
                            <tr key={l.id} className="tr">
                                <td className="td dim">{l.time}</td>
                                <td className="td mono">{l.plate}</td>
                                <td className="td">{l.name}</td>
                                <td className="td">
                    <span className={`badge ${l.status === "allowed" ? "ok" : "bad"}`}>
                      {l.status === "allowed" ? "Engedélyezett" : "Megtagadva"}
                    </span>
                                </td>
                            </tr>
                        ))}
                        </tbody>
                    </table>
                )}
            </div>
        </div>
    );
}

//RENDER
ReactDOM.createRoot(document.getElementById("root")).render(<App />);